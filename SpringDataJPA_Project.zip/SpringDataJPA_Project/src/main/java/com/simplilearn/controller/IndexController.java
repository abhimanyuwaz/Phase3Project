package com.simplilearn.controller;

import java.util.ArrayList;
import java.util.List;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.SystemPropertyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.simplilearn.entity.Category;
import com.simplilearn.entity.Login;

import com.simplilearn.entity.Product;
import com.simplilearn.entity.ProductSave;
import com.simplilearn.entity.PurchaseReport;
import com.simplilearn.entity.User;
import com.simplilearn.service.CategoryService;
import com.simplilearn.service.LoginService;
import com.simplilearn.service.ProductService;
import com.simplilearn.service.PurchaseReportService;
import com.simplilearn.service.UserService;



//@RestController
@Controller
public class IndexController 
{
	@Autowired
	LoginService loginservice;
	@Autowired
	UserService userservice;
	@Autowired 
	CategoryService categoryservice;
	@Autowired
	ProductService productservice;
	@Autowired
	PurchaseReportService purchasereportservice;
	
	@GetMapping("/")
	public String listProducts(Login user) 
	{
		return "Login";
	}
//	
	
	@PostMapping("/passwordcheck")
	public String passwordCheck(Model model)
	{	
	User user =userservice.findUserByUserName("sarora");
		model.addAttribute("user",user);
		return "Change Password";
		
	}
	
	
	
	@PostMapping("/loginuser")
	public ModelAndView userLogin(@ModelAttribute Login login)		
	//public String userLogin()
	{
		System.out.println("Method Reached");
	System.out.println(" Username "+ login.getUsername() );
	System.out.println(" Password "+login.getPassword() );
	
	
	User user =userservice.findUserByUserName(login.getUsername());
	
	ModelAndView mav;
	
	
	if(user.getUserName().equals("admin"))
	{
		if(user.getPassWord().equals(login.getPassword()))
		{
			System.out.println("Logged in Successfully !!");
			 mav=new ModelAndView("index");
			 
		}
		
		
		else
		{
			mav=new ModelAndView("Login");	
		}
		
		
	
	}
	else
	{
		mav=new ModelAndView("Login");
	}
	return mav;
	}
	
	
	@GetMapping("/AddCategory")
	public String addcategory() 
	{
		
		return "AddCategory";
	}
//	
	
	@GetMapping("/ListProduct")
	public String listProducts(Model model) 
	{
		
		Category cat=new Category();
		cat.setCategoryname("Daily User");
		
		categoryservice.saveCategory(cat);
		Product p1= new Product();
		Product p2= new Product();
		Product p3= new Product();
		
		p1.setName("Tooth Brush");
		p1.setPrirce(32);
		p1.setCategory(cat);
		
		p2.setName("Comb");
		p2.setPrirce(50);
		p2.setCategory(cat);
		
		p3.setName("Spoap");
		p3.setPrirce(20);
		p3.setCategory(cat);
		

		productservice.saveProduct(p1);
		productservice.saveProduct(p2);
		productservice.saveProduct(p3);
		
		List<Product> product=productservice.getAllProducts();
		
		
		model.addAttribute("product",product);
		return "ProductDetails";
	}
	
	

	
	@GetMapping("/allusers")
	
	public String listEmployees(Model model)
	{
		List<User> user=userservice.getAllUsers();
		model.addAttribute("user",user);
		return "user-list";
		
	}
	

	
@PostMapping("/saveproduct")
	
	public String saveProduct(@ModelAttribute Product product)
	{
		System.out.println("Reached Sace Product"+product.getName());
		Category cat=product.getCategory();
		System.out.println(cat.getCategoryname());
		categoryservice.saveCategory(cat);
		productservice.saveProduct(product);
		return "index";
		
	}
	


@PostMapping("/AddNewProduct")

public String addProduct(@ModelAttribute ProductSave product)
{
	Product saveproduct= new Product();

	saveproduct.setName(product.getName());
	saveproduct.setPrirce(product.getPrice());
	
	Category c= new Category();
List <Category> categories=	categoryservice.getAllCategory();
for (int i=0;i<categories.size();i++) 
{
	Category cat=(Category)categories.get(i);
	
	if(cat.getCategoryname().equalsIgnoreCase(product.getCategory()))
	{
		c.setCategoryname(cat.getCategoryname());
		c.setCategortid(cat.getCategortid());
	}
	
}

saveproduct.setCategory(c);
productservice.saveProduct(saveproduct);

return "index";
	
}

@GetMapping("/addproduct") 

public ModelAndView addnewProduct()
{
System.out.println("Added Product");
List<Category> category=categoryservice.getAllCategory();
ModelAndView mav=new ModelAndView("AddProduct");
mav.addObject("category", category);
return mav;
	
}

@GetMapping("/editproduct")
	
	public ModelAndView editProduct(@RequestParam int id)
	{
	Product product=productservice.getProductById(id);
		//List<User> user=userservice.getAllUsers();
//	List <User>users=userservice.searchUser(keyword);
	ModelAndView mav=new ModelAndView("EditProduct");
	mav.addObject("product", product);
	return mav;
		
		
	}

@GetMapping("/deleteproduct")

public String deleteProduct(@RequestParam int id)
{
	System.out.println("Deleting the Product "+id);
	productservice.delete(id);
	
	return "index";
	
}

@GetMapping("/searchuser")
public String searchUser() 
{
	return "SearchUser";
}


//public List<User>(String keyword)
//{
//	return 
//}

@PostMapping("/search")
public ModelAndView searchUser(@RequestParam String keyword) 
{
	List <User>users=userservice.searchUser(keyword);
	ModelAndView mav=new ModelAndView("ShowUser");
	mav.addObject("users", users);
	return mav;
	
}



@GetMapping("/updatePasswordPage")

public String updatePasswordNavigation()
{
	return "UpdatePassword";
	
}

	@PostMapping("/updatePassword")
	public String updatePass(@RequestParam String password) 
	{
		User user =userservice.findUserByUserName("admin");
		user.setPassWord(password);
		userservice.saveUser(user);
		return "index";
	}
	@PostMapping("/loginusernew")

	public String changePassword(String username,String password)		
	//public String userLogin()
	{
		
	
	
	
	UserService us=new UserService();
	User user =us.findUserByUserName(username);
	
	if(user!=null)
	{
		us.updatePassword(password, user);
		System.out.println(" Password is Udpated Successfully !");
	}
	else
	{
		System.out.println("User is not Found !");
	}


	return "indexTestNew";
	
	}

	@PostMapping("/AddCategory")
	public String saveCategory(@ModelAttribute Category category) 
	{
		System.out.println("Category "+category.getCategoryname());
		categoryservice.saveCategory(category);
		
		return "index";
	}
				
		@GetMapping("/purchaseReportbydate")
		public ModelAndView purchaseReportbyDate() 
		{
			PurchaseReport pr= new PurchaseReport();
			
			Category cat[]= new Category[2];
			
//         for(int i=0;i<cat.length;i++)
//			{
//			System.out.println("Category Hai");	
//			}
//			
			cat[0]= new Category();
			cat[1]= new Category();
			
			cat[0].setCategoryname("Cosmetics");
			cat[1].setCategoryname("Eatables");
			
			categoryservice.saveCategory(cat[0]);
			categoryservice.saveCategory(cat[1]);
			
			
			Product pro[]= new Product[4];
			pro[0]= new Product();
			pro[1]= new Product();
			pro[2]= new Product();
			pro[3]= new Product();
			
			pro[0].setName("Soap");	
			pro[0].setPrirce(12);
			pro[0].setCategory(cat[0]);
			
			pro[1].setName("Shampoo");	
			pro[1].setPrirce(50);
			pro[1].setCategory(cat[0]);
			
			pro[2].setName("Buscuit");	
			pro[2].setPrirce(30);
			pro[2].setCategory(cat[1]);
			

			
			productservice.saveProduct(pro[0]);
			productservice.saveProduct(pro[1]);
			productservice.saveProduct(pro[2]);
			productservice.saveProduct(pro[3]);
			
			
			User user[]= new User[3];
			
			user[0]= new User();
			user[1]= new User();
			user[2]= new User();
			
			user[0].setFirstname("Alivish");
			user[0].setLastname("Yadav");
			user[0].setUserName("ayadav");
			user[0].setPassWord("test");
			
			user[1].setFirstname("Kratik");
			user[1].setLastname("Mahajan");
			user[1].setUserName("kyadav");
			user[1].setPassWord("test");
			
			user[2].setFirstname("Natasha");
			user[2].setLastname("Sharma");
			user[2].setUserName("nsharma");
			user[2].setPassWord("test");
			
			userservice.saveUser(user[0]);
			userservice.saveUser(user[1]);
			userservice.saveUser(user[2]);
			
			PurchaseReport prreport[]= new PurchaseReport[3];	
			
			prreport[0]= new PurchaseReport();
			prreport[1]= new PurchaseReport();
			prreport[2]= new PurchaseReport();
			
ArrayList <Product> plist= new ArrayList <Product>();
ArrayList <Product> plist1= new ArrayList <Product>();
ArrayList <Product> plist2= new ArrayList <Product>();
			plist.add(pro[0]);
			plist.add(pro[2]);
			plist.add(pro[3]);
			
		
			plist1.add(pro[0]);			
			plist1.add(pro[3]);
			
		
			plist2.add(pro[0]);	
			plist2.add(pro[1]);	
			plist2.add(pro[2]);	
			plist2.add(pro[3]);	
			
			
			
			//= new List <Product>();
			
			prreport[0].setProduct(pro[0]);
			prreport[0].setUsers(user[0]);
			prreport[0].setPurchaseDate("04/01/2023");
			
			purchasereportservice.savePurchaseReport(prreport[0]);
			prreport[1].setProduct(pro[1]);
			prreport[1].setUsers(user[1]);
			prreport[1].setPurchaseDate("04/02/2023");
			purchasereportservice.savePurchaseReport(prreport[1]);
			
			prreport[2].setProduct(pro[2]);
			prreport[2].setUsers(user[2]);
			prreport[2].setPurchaseDate("04/04/2023");
			
			
		
		//	purchasereportservice.savePurchaseReport(prreport[2]);
			
		List<PurchaseReport> purchasereport= purchasereportservice.getAllPurchaseReport();
		
			ModelAndView mav=new ModelAndView("PurchaseReportbyDate");			
			mav.addObject("purchasereport", purchasereport);
			return mav;
			
		}
//		@GetMapping("/purchaseReportByCategory")
//		public ModelAndView purchaseReportbyCategory() 
//		{
//			ModelAndView mav=new ModelAndView("PurchaseReportbyCategory");
//			mav.addObject("product", product);
//			return mav;
//		}
	
}
