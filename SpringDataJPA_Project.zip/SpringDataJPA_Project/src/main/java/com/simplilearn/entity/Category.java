package com.simplilearn.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Category 
{
	@Id
	@GeneratedValue
	int categortid;
	String categoryname;
	public int getCategortid() 
	{
		
		return categortid;
	}
	public void setCategortid(int categortid) 
	{
		this.categortid = categortid;
	}
	public String getCategoryname() 
	{
		return categoryname;
	}
	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}
	
}
