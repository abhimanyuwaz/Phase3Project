package com.simplilearn.entity;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class PurchaseReport 
{

	@Id
	@GeneratedValue
	int id;
	Date purchaseDate;
	public int getId() {
		return id;
	}
	public void setId(int id) 
	{
		this.id = id;
	}
	public Date getPurchaseDate() 
	{
		return purchaseDate;
	}
	public void setPurchaseDate(String purDate) 
	{
		DateFormat format = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
	
		try 
		{
			this.purchaseDate = format.parse(purDate);
		}
		
		catch(Exception e)
		{
			System.out.println(e);
			
		}
	}
	
	@OneToOne
	private User users;

	public User getUsers() 
	{
		return users;
	}
	public void setUsers(User users) 
	{
		this.users = users;
	}
	
	@OneToOne
	private Product product;
	public Product getProduct() 
	{
		return product;
	}
	public void setProduct(Product product) 
	{
		this.product = product;
	}
	
	
//	private List<Product> product;
//	public List<Product> getProudct() {
//		return product;
//	}
//	public void setProudct(List<Product> proudct) 
//	{
//		this.product = proudct;
//	}
	
	
}
