package com.simplilearn.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Product 
{
	/**
	 * 
	 */
	@Id
	@GeneratedValue
	int id;
	public String name;
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}

	public int prirce;
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrirce() {
		return prirce;
	}
	public void setPrirce(int prirce) {
		this.prirce = prirce;
	}

	@ManyToOne
	private  Category category;
}
