package com.simplilearn.entity;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import net.bytebuddy.agent.builder.AgentBuilder.FallbackStrategy.Simple;
public class TestJava {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		try
		{
			
			
			DateFormat format = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
			
		
				Date purchaseDate = format.parse("05/11/1994");
				System.out.println(purchaseDate);
			
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		

	}
	public void setPurchaseDate(String purDate) 
	{
		DateFormat format = new SimpleDateFormat("MM.dd.yyyy", Locale.ENGLISH);
	
		try 
		{
			Date purchaseDate = format.parse(purDate);
		}
		
		catch(Exception e)
		{
			System.out.println(e);
			
		}
	}

}
