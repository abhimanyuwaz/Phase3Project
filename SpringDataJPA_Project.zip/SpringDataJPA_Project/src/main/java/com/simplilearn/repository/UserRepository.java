package com.simplilearn.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.simplilearn.entity.User;

@Repository
public interface UserRepository extends CrudRepository<User, Integer>
{	
	Optional<User> findByusername(String username);
	//Optional<User> findallUsers();
	
	 @Query(value = "SELECT u FROM User u WHERE u.firstname LIKE '%' || :keyword || '%'"
	            + " OR u.lastname LIKE '%' || :keyword || '%'"
	            + " OR u.username LIKE '%' || :keyword || '%'")
	    public List<User> searchUser(@Param("keyword") String keyword);
	 
	 
//	
//
	//Movie findByName(String name);
	//User findByUsername(String username);
	
//	@Query("select u from User u where u.username=userName")
//	User findUserByUserName(@Param("userName") String userName);
//	
//	
	
	
	
}


