package com.simplilearn.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.simplilearn.entity.Category;

import com.simplilearn.entity.User;
@Repository
public interface CategoryRepository extends CrudRepository<Category, Integer>
{

	

}



