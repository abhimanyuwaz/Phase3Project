package com.simplilearn.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.simplilearn.entity.Login;


@Repository
public interface LoginRepository extends CrudRepository<Login, Integer>
{
	Login findByusername(String username);
	
	List<Login> findLoginByUsername(@Param("username") String username);
	
//	@Modifying
//	@Query("update Login  set password =: password where username =:")
//	public void changePassword(@Param("password") String password,@Param("username") String username); 
//	
	//public void deactivateUsersNotLoggedInSince(@Param("password") String password); 
	
}
