package com.simplilearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpa09102022Application 
{

	public static void main(String[] args) 
	{
		SpringApplication.run(SpringDataJpa09102022Application.class, args);
	}

	
}
