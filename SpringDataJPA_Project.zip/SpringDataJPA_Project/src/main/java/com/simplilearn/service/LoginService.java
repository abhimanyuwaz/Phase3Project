package com.simplilearn.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;


import com.simplilearn.entity.Login;

import com.simplilearn.entity.User;
import com.simplilearn.repository.LoginRepository;

@Service
public class LoginService 
{

	@Autowired
	LoginRepository loginRepository;
	
	
	public List<Login> findByName(String username)
	{
	
		List <Login>users= new ArrayList<Login>();
		loginRepository.findAll().forEach(u->users.add(u));
		
		
		return users;
		
	}
	
	//public void deactivateUsersNotLoggedInSince(); 
	
	public void changePassword(@Param("password") String password,@Param("username") String username) 
	{
	
		System.out.println("Password Updated ! "+password);
	}
	
	public void updatePassword(String passwors )
	{
		
	}
//	
	public void saveLogin(Login login) 
	{
		
		loginRepository.save(login);
	}
	
	public void  getAllLoginUsers() 
	{
		
		
	}

}
