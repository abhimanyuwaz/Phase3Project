package com.simplilearn.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simplilearn.entity.Login;

import com.simplilearn.entity.Product;
import com.simplilearn.entity.User;
import com.simplilearn.repository.UserRepository;

@Service
public class UserService 
{

	@Autowired
	UserRepository userreporisitory;
	
	
	public void saveUser(User user)
	{
		userreporisitory.save(user);
	
		
	}
	
	public User findUserByUserName(String username)
	{
	
		
		List <User>users= new ArrayList<User>();
		System.out.println("---------------------Finding the User : "+username);
		userreporisitory.findAll().forEach(u->users.add(u));
		
		 //User user=(User)userreporisitory.findByusername(username);
		for(int i=0;i<users.size();i++)
		{
			User user=(User)users.get(i);
		
			if(username.equalsIgnoreCase(user.getUserName()))
			{
				return user;
			}
			
		}
			
		return null;
		
	}

	public List<User> getAllUsers()
	{
		List <User>users= new ArrayList<User>();
		//System.out.println("---------------------Finding the User : "+username);
		userreporisitory.findAll().forEach(u->users.add(u));
		
		return users;
		
	}
	
	public List<User> searchUser(String keyword)
	{
		
		return userreporisitory.searchUser(keyword);
	}
	
	public void updatePassword(String password,User user)
	{
		user.setPassWord(password);
	
		userreporisitory.save(user);
	}
	

//	public List<User> findUserByUserName()
//	{
//	
//		List <User>users= new ArrayList<User>();
//		userreporisitory.findAll().forEach(u->users.add(u));
//		return users;
//		
//	}
	
	
}
