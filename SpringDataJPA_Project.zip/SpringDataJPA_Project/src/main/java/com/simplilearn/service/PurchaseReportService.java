package com.simplilearn.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simplilearn.entity.Category;
import com.simplilearn.entity.PurchaseReport;
import com.simplilearn.repository.PurchaseReportRepository;

@Service
public class PurchaseReportService {
	
	@Autowired
	PurchaseReportRepository purchasereportrepository;
	
public void savePurchaseReport(PurchaseReport preport)
{
	purchasereportrepository.save(preport);
	
}

public List<PurchaseReport> getAllPurchaseReport() 
{
	List<PurchaseReport> preport = new ArrayList<PurchaseReport>();
	purchasereportrepository.findAll().forEach(c -> preport.add(c));
	return preport;
}
}
