package com.simplilearn.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simplilearn.entity.Category;
import com.simplilearn.entity.Product;
import com.simplilearn.entity.User;
import com.simplilearn.repository.ProductReporsitory;

@Service
public class ProductService 
{
	@Autowired 
	ProductReporsitory productRepository;
	
	
	

	public List<Product> getAllProducts()
	{
		List <Product>products= new ArrayList<Product>();
		//System.out.println("---------------------Finding the User : "+username);
		productRepository.findAll().forEach(u->products.add(u));
		
		return products;
		
	}

	public Product getProductById(int id)
	{
		List <Product>products= new ArrayList<Product>();
		//System.out.println("---------------------Finding the User : "+username);
		productRepository.findAll().forEach(u->products.add(u));
		
		for(int i=0;i<products.size();i++)
		{
			Product product=(Product)products.get(i);
			if(product.getId()==id)
			{
				return product;
			}
		}
		
		
		return null;
		
	}
	public void delete(int id) 
	{
		productRepository.deleteById(id);
	}
	public void saveProduct(Product product)
	{
		productRepository.save(product);
	
		
	}

}
