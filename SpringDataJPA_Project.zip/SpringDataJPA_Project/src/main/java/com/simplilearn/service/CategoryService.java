package com.simplilearn.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.simplilearn.entity.Category;

import com.simplilearn.entity.Product;
import com.simplilearn.repository.CategoryRepository;
import com.simplilearn.repository.ProductReporsitory;

@Service
public class CategoryService 
{
	@Autowired 
	CategoryRepository categoryRepository;
	
	
	public List<Category> getAllCategory() 
	{
		List<Category> category = new ArrayList<Category>();
		categoryRepository.findAll().forEach(c -> category.add(c));
		return category;
	}

	
	public void saveCategory(@RequestBody Category category)
	{
		categoryRepository.save(category);
	
		
	}

}
